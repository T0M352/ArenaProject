using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThiefClass : PlayerOne
{

    public GameObject ultArea;
    public GameObject legs;
    private Animator legAnimator;


    protected override void Start()
    {
        base.Start();
        legAnimator = legs.GetComponent<Animator>();
    }
    protected override void Update()
    {
        base.Update();
        if (Input.GetKeyUp(KeyCode.F) && gameObject.name == "Player1Thief" && stamina > 10 && Time.time - lastAttack > cooldown && isAtacking == false)
        {
            isAtacking = true;
            stamina -= 10;
            lastAttack = Time.time;
            animator.Play("thief_attack");
        }

        if (Input.GetKeyUp(KeyCode.Keypad1) && gameObject.name == "Player2Thief" && stamina > 10 && Time.time - lastAttack > cooldown && isAtacking == false) //&& GameManager.isAtacking == false) // atak gracza 2 z klasa barbarian
        {
            isAtacking = true;
            stamina -= 10;
            lastAttack = Time.time;
            animator.Play("thief_attack");
        }

        if (Input.GetKeyUp(KeyCode.H) && ultTimer == 0 && gameObject.name == "Player1Thief") //  gameObject.name == "Player1Thief" &&
        {
            ultTimer = 100;
            StartCoroutine(ThiefUlt());

        }
        if (Input.GetKeyUp(KeyCode.Keypad3) && ultTimer == 0 && gameObject.name == "Player2Thief")// && gameObject.name == "Player2Thief"
        {
            ultTimer = 100;
            StartCoroutine(ThiefUlt());

        }


    }

    protected override void FixedUpdate()
    {
        base.FixedUpdate();
        if (moveDirectory == Vector3.zero)  //ZMIANA ANIMACJI RUCHU NA BIEG
            legAnimator.SetBool("isMoving", false);
        else
            legAnimator.SetBool("isMoving", true);
    }



        private void enableThiefAttack()
    {
            attackArea.GetComponent<BoxCollider2D>().enabled = true;
    }

    private void disableThiefAttack()
    {
        attackArea.GetComponent<BoxCollider2D>().enabled = false;
    }

    private void enableThiefUlt()
    {
        ultArea.GetComponent<BoxCollider2D>().enabled = true;
    }

    private void disableThiefUlt()
    {
        ultArea.GetComponent<BoxCollider2D>().enabled = false;
    }


    IEnumerator ThiefUlt()
    {
        animator.Play("thief_ult");
        yield return new WaitForSeconds(2.0f);
        animator.Play("thief_idle");
    }

    private void switchToIdleThief()
    {
        animator.Play("thief_idle");
    }

}
