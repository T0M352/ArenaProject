using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Destroyable : MonoBehaviour
{
    private float lastImmune;
    private float immuneTime = 0.5f;
    public float health = 5f;
    private Animator animator;

    private void Start()
    {
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        if(health < 0)
        {
            animator.Play("barrel_destroy");
        }
    }
    protected virtual void ReciveDamage(Damage dmg)
    {
        if (Time.time - lastImmune > immuneTime)
        {
            lastImmune = Time.time;
            GameManager.instance.ShowText("-" + dmg.damageAmount.ToString(), 25, Color.red, transform.position, Vector3.up * 30, 1.0f);
            health -= dmg.damageAmount;
        }
    }

    private void destroed()
    {
        Destroy(gameObject);
    }
}
