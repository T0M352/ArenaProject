using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collidable : MonoBehaviour
{
    public ContactFilter2D filter;
    private BoxCollider2D boxCollider;
    private Collider2D[] hits = new Collider2D[10];

    protected virtual void Start()
    {
        boxCollider = GetComponent<BoxCollider2D>();
    }

    protected virtual void Update() // protected to private z dostepem dla dziedziczacych klas
    {
        boxCollider.OverlapCollider(filter, hits);
        for (int i = 0; i < hits.Length; i++)
        {
            if (hits[i] == null)
                continue;

            //if (this.tag == "Skrzynia")
            //
            //przyznaj golda
            //

            //Debug.Log.Log(hits[i].name);
            OnColllide(hits[i]);    

            hits[i] = null; // czyscimy tablice z informacja o obiektach w kolizji

        }
    }

    protected virtual void OnColllide(Collider2D coll) // virtual daje mozliwosc edycji medoty w podklasie dziedzicz�cej
    {
        Debug.Log("Nie zadeklarowa�e� metody onColide w " + this.name);
    }
    
}
