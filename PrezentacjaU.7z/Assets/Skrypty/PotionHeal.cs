using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PotionHeal : Collidable
{
    public int healingAmount = 1;

    protected override void OnColllide(Collider2D coll)
    {
        if(coll.name == "Player1")
            GameManager.instance.player.Heal(healingAmount);
        else if (coll.name == "Player2")
            GameManager.instance.player2.Heal(healingAmount);
        Destroy(gameObject);
    }
}
