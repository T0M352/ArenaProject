using Mono.Cecil;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Rendering;

public class EnemyKobold : MonoBehaviour
{
    protected Animator animator;
    protected Rigidbody2D rb;
    [SerializeField]
    protected GameObject attackArea;
    [SerializeField]
    protected float moveSpeed;
    [SerializeField]
    protected float health;
    [SerializeField]
    protected float attackDist;
    [SerializeField]
    protected float backDist;
    [SerializeField]
    protected float knockTime;
    [SerializeField]
    protected Transform startPos;

    protected float immuneTime = 0.5f;
    protected float lastImmune;
    protected Transform target;
    protected Vector2 moveDirectory;
    protected bool isAttacking;
    protected bool goBack;
    protected Vector3 pushDirection;
    protected float pushForce;

    protected Transform otherEnemy;

    protected float distBeetwenEnemies;

    public float distanceEnemies;
    public float readyDist;
    protected bool defMode;
    public Transform targetBall;
    public float targetBallSpeed;
    public float targetBallDist;
    public GameObject legs;
    private Animator legAnimator;

    protected virtual void Start()
    {
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        animator.Play("kobold_idle");
        legAnimator = legs.GetComponent<Animator>();

    }

    protected virtual void Update()
    {
        if (target != null)
        {
            targetBall.position = target.position + new Vector3(-Mathf.Cos(Time.time * targetBallSpeed) * targetBallDist, Mathf.Sin(Time.time * targetBallSpeed) * targetBallDist, 0);
        }

        if (health < 0)
        {
            Destroy(rb);
            Death();

        }

        if (isAttacking == false)
            attackArea.GetComponent<BoxCollider2D>().enabled = false;
    }

    protected virtual void FixedUpdate()
    {
        if (rb != null) //DODAJ STREFFE W KTOREJ BO ZBLIZENIU PODNOSI TARCZE I IDZIE WOLNIEJ DODAJ KULKE OKRAZAJACA GRACZA ZA KTORA BEDZIE PODAZAL I DODAJ FUNKCJE PRZEZ KTORA NIE BEDA WCHODZIC W SIEBIE EWENTUALNIE ISC SLALOMEM SZUKAJ CHANGE RIGIDBODY.VELOCITY DIRECTIOn

        {
            //WROG W ZASIEGU
            if (target != null)
            {
                float dist = Vector3.Distance(target.position, transform.position);



                if (goBack == false && dist > readyDist && isAttacking == false)// && distBeetwenEnemies > distanceEnemies) //TEST TEGO ZEBY NIE BLOKOWALI SIE O SIEBIE
                {
                    moveDirectory = (target.position - transform.position).normalized;
                    rb.velocity = moveDirectory * moveSpeed;
                }


                if (dist < readyDist && dist > attackDist && isAttacking == false)
                {
                    moveDirectory = (targetBall.position - transform.position).normalized; //PODAZA W KOLKO ZA GRACZEM
                    rb.velocity = moveDirectory * moveSpeed / 2;
                }
                else if (dist < attackDist)
                    Attack();
                else
                    UnAttack();


                //WYCOFANIE PO ATAKU
                if (goBack == true)
                {
                    moveDirectory = (transform.position - target.position).normalized;
                    rb.velocity = moveDirectory * moveSpeed / 2;
                    if (dist > backDist)
                    {
                        moveDirectory = Vector3.zero;
                        goBack = false;
                    }
                }





                //if(otherEnemies.Count != 0)
                //{
                //    for(int i = 0; i < otherEnemies.Count; i++)
                //    {
                //        float distBeetwenEnemies = Vector3.Distance(otherEnemies[i].transform.position, transform.position);
                //        if(distBeetwenEnemies < 0.25)
                //        {
                //            moveDirectory = (transform.position - otherEnemies[i].transform.position).normalized;
                //            rb.velocity = moveDirectory * moveSpeed;
                //        }
                //    }
                //
                // }
                //if(otherEnemy != null) //TEST TEGO ZEBY NIE BLOKOWALI SIE O SIEBIE TODO:
                //{
                //            distBeetwenEnemies = Vector3.Distance(otherEnemy.transform.position, transform.position);
                //            if(distBeetwenEnemies < distanceEnemies)
                //            {
                //        Debug.Log("Oddalam sie");
                //        // rb.velocity = Quaternion.AngleAxis(90.0f, moveDirectory) * rb.velocity;
                //        moveDirectory = (transform.position - otherEnemy.position).normalized;
                //        rb.velocity = moveDirectory * moveSpeed;
                //    }
                //}

            }
            else if (target == null)
            {
                if (Vector3.Distance(startPos.position, transform.position) > 0.1)
                {
                    moveDirectory = (startPos.position - transform.position).normalized;
                    rb.velocity = moveDirectory * moveSpeed;
                }
                else
                {
                    moveDirectory = Vector2.zero;
                    rb.velocity = Vector2.zero;
                    //animator.Play("goblin_idle");
                }

            }


            if (goBack == false)// && distBeetwenEnemies < distanceEnemies) // TEST PAMIETAJ O TYM TODO:
            {
                if (moveDirectory.x > 0)  // ZMIANA KIERUNKU SPRITE
                    transform.localScale = new Vector3(0.5f, 0.5f, 1);
                else if (moveDirectory.x < 0)
                    transform.localScale = new Vector3(-0.5f, 0.5f, 1);
            }
            if (rb.velocity == Vector2.zero)  //ZMIANA ANIMACJI RUCHU NA BIEG
                legAnimator.SetBool("isMoving", false);
            else
                legAnimator.SetBool("isMoving", true);

            if (pushDirection != Vector3.zero)  //KNOCKBACK
            {
                rb.AddForce(pushDirection * pushForce, ForceMode2D.Impulse);
                StartCoroutine(Knockback());
            }
        }
    }



    protected virtual void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
            target = collision.transform;

        if (collision.tag == "Fighter") //TEST TEGO ZEBY NIE BLOKOWALI SIE O SIEBIE
            otherEnemy = collision.transform;
    }

    protected virtual void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
            target = null;

        if (collision.tag == "Fighter") //TEST TEGO ZEBY NIE BLOKOWALI SIE O SIEBIE
            otherEnemy = null;

    }
    private IEnumerator Knockback()
    {
        yield return new WaitForSeconds(knockTime);
        pushDirection = Vector2.zero;
        pushForce = 0;
    }

    protected virtual void switchToIdle()
    {
        animator.Play("kobold_idle");
    }

    protected virtual void enableAttack()
    {

        attackArea.GetComponent<BoxCollider2D>().enabled = true;
    }

    protected virtual void disableAttack()
    {
        attackArea.GetComponent<BoxCollider2D>().enabled = false;
        goBack = true;
    }

    protected virtual void ReciveDamage(Damage dmg)
    {
        if (Time.time - lastImmune > immuneTime)
        {
            lastImmune = Time.time;
            pushDirection = (transform.position - target.transform.position).normalized;
            pushForce = dmg.pushForce;
            GameManager.instance.ShowText("-" + dmg.damageAmount.ToString(), 25, Color.red, transform.position, Vector3.up * 30, 1.0f);
            health -= dmg.damageAmount;
        }
    }

    protected virtual void Attack()
    {
        animator.Play("kobold_attack");
        isAttacking = true;
    }

    protected virtual void UnAttack()
    {
        isAttacking = false;
        animator.Play("kobold_idle");
    }




    protected virtual void Death()
    {
        target = null;
        animator.Play("kobold_death");
    }

    private void Destroy()
    {
        Destroy(gameObject);
    }


}
