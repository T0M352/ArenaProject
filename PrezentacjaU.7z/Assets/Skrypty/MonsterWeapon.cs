using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterWeapon : Collidable
{
    public int Damage;
    public float Push;
    protected override void OnColllide(Collider2D coll)
    {
        if (coll.tag == "Player")
        {
            Damage dmg = new Damage();
            dmg.damageAmount = Damage;
            dmg.origin = transform.position;
            dmg.pushForce = Push;
            Debug.Log("Dziala");
            coll.SendMessage("ReciveDamage", dmg);
        }



    }
}
