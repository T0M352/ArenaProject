using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : Collidable
{
    //obra�enia
    public int damagePoint = 1;
    public float pushForce = 2.0f;
   

    //ulepszenia
    public int weponLevel = 0;
    private SpriteRenderer spirteRenderer;

    //Machniecie
    private Animator anim;
    private float cooldown = 0.5f;
    private float lastSwing;


    protected override void Start()
    {
        base.Start();
        spirteRenderer = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();
        
    }

    protected override void Update()
    {
        base.Update();

        if (Input.GetKeyDown(KeyCode.F) && GameManager.instance.player.stamina>10 && Time.time - lastSwing > cooldown) //&& GameManager.isAtacking == false) // klawisz ataku ZROB TO DOBRZE
        {
            if(Time.time - lastSwing > cooldown)
            {
                lastSwing = Time.time;
                if (gameObject.name == "miecz_01") //probowalo animowa� obszar ulta
                Swing();
            }
        }
    }

    public void Swing()
    {
        GameManager.instance.player.stamina -= 10;  
        anim.SetTrigger("Swing");
        //anim.setInt anim.setBool przydatne
    }

    protected override void OnColllide(Collider2D coll)
    {
        if (coll.tag == "Fighter" || coll.tag == "Player")
        {
            if (coll.name == "Player1Barb" || coll.name == "Player1Knight" || coll.name == "Player1Thief" || coll.name == "Player1Mage")
                return;
            Damage dmg = new Damage();
            dmg.damageAmount = damagePoint;
            dmg.origin = transform.position;
            dmg.pushForce = pushForce;

            coll.SendMessage("ReciveDamage", dmg);
        }

      
        
    }

}
