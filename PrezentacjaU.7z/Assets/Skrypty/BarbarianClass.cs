using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarbarianClass : PlayerOne
{
    public GameObject ultBarbOb;

    protected override void Update()
    {
        base.Update();
        if (Input.GetKeyUp(KeyCode.Keypad1) && stamina > 10 && Time.time - lastAttack > cooldown && isAtacking == false && gameObject.name == "Player2Barb")
        {
            isAtacking = true;
            stamina -= 10;
            lastAttack = Time.time;
            animator.Play("barb_attack");
        }

        if (Input.GetKeyUp(KeyCode.F) && stamina > 10 && Time.time - lastAttack > cooldown && isAtacking == false && gameObject.name == "Player1Barb")
        {
            isAtacking = true;
            stamina -= 10;
            lastAttack = Time.time;
            animator.Play("barb_attack");
        }

        if (Input.GetKeyUp(KeyCode.H) && gameObject.name == "Player1Barb" && ultTimer == 0)
        {
            ultTimer = 100;
            animator.Play("barb_ult");

        }

        if (Input.GetKeyUp(KeyCode.Keypad3) && gameObject.name == "Player2Barb" && ultTimer == 0)
        {
            ultTimer = 100;
            animator.Play("barb_ult");

        }
    }

    protected override void FixedUpdate()
    {
        base.FixedUpdate();
        if (moveDirectory == Vector3.zero)  //ZMIANA ANIMACJI RUCHU NA BIEG
            animator.SetBool("isMoving", false);
        else
            animator.SetBool("isMoving", true);
    }

    private void switchToIdle()
    {
        animator.Play("barb_idle");
    }

    private void enableBarbUlt()
    {
        ultBarbOb.GetComponent<BoxCollider2D>().enabled = true;

    }

    private void disableBarbUlt()
    {
        ultBarbOb.GetComponent<BoxCollider2D>().enabled = false;

    }

    private void enableBarbAttack()
    {
        attackArea.GetComponent<BoxCollider2D>().enabled = true;
    }

    private void disableBarbAttack()
    {
        attackArea.GetComponent<BoxCollider2D>().enabled = false;
    }
}
