using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skrzynia : Collectable // dziedziczymy z skryptu kolizji
{
    public Sprite pustaSkrzynia;
    public int iloscZlota = 10;
    protected override void OnCollect()
    {
        if (!collected)
        {
            collected = true;
            GetComponent<SpriteRenderer>().sprite = pustaSkrzynia;
            GameManager.instance.ShowText("+10 golda", 25, Color.yellow, transform.position, Vector3.up * 30, 1.5f);
            Debug.Log("test");
        }
    }
}
