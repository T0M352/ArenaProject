using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using static Unity.VisualScripting.Member;

public class PlayerOne : Fighter
{
    protected BoxCollider2D boxCollider;
    protected RaycastHit2D hit;
    private bool isDashing;
    private bool isDashingP2;
    protected Animator animator;
    public float maxStamina = 100;
    public float stamina = 100;
    public float StaminaIncreasePerFrame = 4.0f;
    public float ultTimer = 0;
    public float ultTimerPerFrame = 2f;
    protected float lastAttack;
    protected float cooldown = 0.5f;


    public GameObject attackArea;


    protected bool isAtacking = false;

    protected Rigidbody2D rb;
    public Vector3 moveDirectory;
    protected const float moveSpeed = 1f;

    
    public float knockTime = 0.2f;
    public float dashSpeed;
    public float dashTime;

    private int isBlocking;
    public GameObject blok;
    public float blokStamina;

    public bool canDash = false;



  





    protected virtual void Start()
    {
        boxCollider = GetComponent<BoxCollider2D>();
        animator = GetComponent<Animator>();
        animator.SetBool("isMoving", false);
        rb = GetComponent<Rigidbody2D>();
        canDash = true;
    }


    protected virtual void Update()
    {
        stamina = Mathf.Clamp(stamina + (StaminaIncreasePerFrame * Time.deltaTime), 0.0f, maxStamina);  // wzrost staminy z czasem
        ultTimer = Mathf.Clamp(ultTimer - (ultTimerPerFrame * Time.deltaTime), 0.0f, 100);

        if (canDash == true)
        {

            if (gameObject.name == "Player1Barb" || gameObject.name == "Player1Knight" || gameObject.name == "Player1Thief" || gameObject.name == "Player1Mage")  //KLASOWE
            {
                
                if (Input.GetKeyUp(KeyCode.G) && isDashing == false && stamina > 20) //dash gracza nr 1
                {
                    canDash = false;

                    stamina -= 20;
                    if (gameObject.name == "Player1Mage")
                        animator.Play("mage_dash");
                    else
                        isDashing = true;
                }
            }

            if (gameObject.name == "Player2Barb" || gameObject.name == "Player2Knight" || gameObject.name == "Player2Thief" || gameObject.name == "Player2Mage")  //KLASOWE
            {
                if (Input.GetKeyUp(KeyCode.Keypad2) && isDashingP2 == false && stamina > 20) //dash gracza nr 2
                {
                    canDash = false;
                    stamina -= 20;
                    Debug.Log("Tu dzia�a");
                    if (gameObject.name == "Player2Mage" && isDashingP2 == false)
                        animator.Play("mage_dash");
                    else
                        isDashingP2 = true;
                }
            }
        }
        if (gameObject.name == "Player1Barb" && Input.GetKey(KeyCode.Space) || gameObject.name == "Player1Knight" && Input.GetKey(KeyCode.Space) || gameObject.name == "Player1Thief" && Input.GetKey(KeyCode.Space) || gameObject.name == "Player1Mage" && Input.GetKey(KeyCode.Space))  //KLASOWE
        {
            stamina = Mathf.Lerp(stamina, 0, blokStamina);
            if (stamina > 15) //dash gracza nr 1
            {
                blok.SetActive(true);
                lastImmune = Time.time + 1f;
            }

        }
        else if (gameObject.name == "Player2Barb" && Input.GetKey(KeyCode.Keypad0) || gameObject.name == "Player2Knight" && Input.GetKey(KeyCode.Keypad0) || gameObject.name == "Player2Thief" && Input.GetKey(KeyCode.Keypad0) || gameObject.name == "Player2Mage" && Input.GetKey(KeyCode.Keypad0))
        {
            stamina = Mathf.Lerp(stamina, 0, blokStamina);
            if (stamina > 15) //dash gracza nr 1
            {
                blok.SetActive(true);
                lastImmune = Time.time + 1f;
            }
        }
        else
        {
            blok.SetActive(false);
        }
    }



    protected virtual void FixedUpdate()
    {


        if (transform.name == "Player1Barb" || transform.name == "Player1Knight" || transform.name == "Player1Thief" || transform.name == "Player1Mage") // KLASY
        {
            float x = Input.GetAxisRaw("Horizontal");
            float y = Input.GetAxisRaw("Vertical");
            //UpdateMotor(new Vector3(x, y, 0));
            if(isDashing==false)
            moveDirectory = new Vector3(x, y).normalized;
        }
        else if (transform.name == "Player2Barb" || transform.name == "Player2Knight" || transform.name == "Player2Thief" || transform.name == "Player2Mage") //KLASY
        {
            float x = Input.GetAxisRaw("Horizontal2");
            float y = Input.GetAxisRaw("Vertical2");
            //UpdateMotor(new Vector3(x, y, 0));
            if(isDashingP2==false)
            moveDirectory = new Vector3(x, y).normalized;
        }
        
        rb.velocity = moveDirectory * moveSpeed;  //RUCH GRACZA


        if (moveDirectory.x > 0)  // ZMIANA KIERUNKU SPRITE
        {
            if(gameObject.name == "Player1Mage" || gameObject.name == "Player2Mage")
                transform.localScale = new Vector3(0.4f, 0.4f, 1);
            else
                transform.localScale = new Vector3(0.6f, 0.6f, 1);
        }

        else if (moveDirectory.x < 0)
        {
           if (gameObject.name == "Player1Mage" || gameObject.name == "Player2Mage")
                transform.localScale = new Vector3(-0.4f, 0.4f, 1);
           else
                transform.localScale = new Vector3(-0.6f, 0.6f, 1);

        }


        if (pushDirection != Vector3.zero)  //KNOCKBACK
        {
            rb.AddForce(pushDirection * PushForce, ForceMode2D.Impulse);
            StartCoroutine(Knockback());
        }

        if(isDashing == true)
        {
            rb.AddForce(moveDirectory * dashSpeed, ForceMode2D.Impulse);
            StartCoroutine(dashP1());
        }

        if (isDashingP2 == true)
        {
            rb.AddForce(moveDirectory * dashSpeed, ForceMode2D.Impulse);
            StartCoroutine(dashP2());
        }

    }




    public void Heal(int healingAmount)
    {
        hitPoint += healingAmount;
        if (hitPoint > maxHitPoint)
            hitPoint = maxHitPoint;
        GameManager.instance.ShowText("+" + healingAmount.ToString(), 25, Color.green, transform.position, Vector3.up * 30, 1.0f);
        GameManager.instance.OnHitpointChange();
    }

    protected override void ReciveDamage(Damage dmg)
    {
        base.ReciveDamage(dmg);
        GameManager.instance.OnHitpointChange();
    }

    protected override void Death()
    {
        if (gameObject.name == "Player1Barb" && GameManager.PlayerOneLives > 0)
        {
            animator.Play("barb_death");
        }

        if (gameObject.name == "Player1Knight" && GameManager.PlayerOneLives > 0)
        {
            animator.Play("rycerz_death");

        }

        if (gameObject.name == "Player1Thief" && GameManager.PlayerOneLives > 0)
        {
            animator.Play("thief_death");
        }

        if (gameObject.name == "Player1Mage" && GameManager.PlayerOneLives > 0)
        {
            animator.Play("mage_death");

        }

        if (gameObject.name == "Player2Barb" && GameManager.PlayerTwoLives > 0)
        {
            animator.Play("barb2_death");
            
        }

        if (gameObject.name == "Player2Knight" && GameManager.PlayerTwoLives > 0)
        {
            animator.Play("rycerz2_death");
        }

        if (gameObject.name == "Player2Thief" && GameManager.PlayerTwoLives > 0)
        {
            animator.Play("thief2_death");

        }
        if (gameObject.name == "Player2Mage" && GameManager.PlayerOneLives > 0)
        {
            animator.Play("mage2_death");

        }

    }



    private void isAttackingFalse()
    {
        isAtacking = false;
    }

    private void Destroy()
    {
        Destroy(gameObject);
    }

    private void repsawnP1()
    {
        GameManager.respawnPlayerOne = true;
    }
    
    private void respawnP2()
    {
        GameManager.respawnPlayerTwo = true;
    }


    private IEnumerator Knockback()
    {
        yield return new WaitForSeconds(knockTime);
        pushDirection = Vector2.zero;
        PushForce = 0;
    }

    private IEnumerator dashP1()
    {
        //boxCollider.enabled = false; // wy��czam boxcolider dla niesmiertelnosci podczas dasha
        int Layer = LayerMask.NameToLayer("dashingLayer"); // nazwa layera potrzebna na pozniej
        gameObject.layer = Layer; // zmieniam layer wroga zeby moc przez niego przenikac
        animator.SetBool("isDash", true); //odwolanie do animatora, klatka dashu
        yield return new WaitForSeconds(dashTime);
        animator.SetBool("isDash", false); //powrot do stanu animacji idle
        //boxCollider.enabled = true; // w�aczam spowrotem wrazliwosc na ataki
        int LayerPostac = LayerMask.NameToLayer("Posta�");
        gameObject.layer = LayerPostac; // zmiana layeru spowrotem
        isDashing = false;
        canDash = true;
    }

    private IEnumerator dashP2()
    {
        //boxCollider.enabled = false; // wy��czam boxcolider dla niesmiertelnosci podczas dasha
        int Layer = LayerMask.NameToLayer("dashingLayer");
        gameObject.layer = Layer; 
        animator.SetBool("isDash", true); //odwolanie do animatora, klatka dashu
        yield return new WaitForSeconds(dashTime);
        animator.SetBool("isDash", false); //powrot do stanu animacji idle
        //boxCollider.enabled = true; // w�aczam spowrotem wrazliwosc na ataki
        int LayerPostac = LayerMask.NameToLayer("Posta�");
        gameObject.layer = LayerPostac; // zmiana layeru spowrotem
        isDashingP2 = false;
        canDash = true;
    }

    private void mageDash()
    {
        rb.AddForce(moveDirectory * dashSpeed, ForceMode2D.Force);
        int Layer = LayerMask.NameToLayer("dashingLayer");
        gameObject.layer = Layer;
    }

    private void isDashingFalse()
    {
        canDash = true;

    }

}