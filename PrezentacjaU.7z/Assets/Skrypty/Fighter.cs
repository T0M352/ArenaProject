using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Fighter : MonoBehaviour
{
    public int hitPoint = 10;
    public int maxHitPoint = 10;
    public float pushRecoverySpeed = 0.2f;

    protected float immuneTime = 0.5f; //TODO: POBAW SIE Z TYM
    protected float lastImmune;

    protected Vector3 pushDirection;
    //public Rigidbody2D rigidbody2D;
    protected Vector2 pushDir;
    protected float PushForce;



    protected virtual void ReciveDamage(Damage dmg)
    {
        if(Time.time - lastImmune > immuneTime)
        {
            lastImmune = Time.time;
            hitPoint -= dmg.damageAmount;
            if (transform.name == "Player1Barb" || transform.name == "Player1Knight" || transform.name == "Player1Thief" || transform.name == "Player1Mage")
            {
                pushDirection = (GameManager.posP1 - GameManager.posP2).normalized;
            }
            else
            {
                pushDirection = (GameManager.posP2 - GameManager.posP1).normalized;
            }
            pushDir = (transform.position - dmg.origin).normalized;
            PushForce = dmg.pushForce;
            if(gameObject.name != "blok")
            GameManager.instance.ShowText("-" + dmg.damageAmount.ToString(), 25, Color.red, transform.position, Vector3.up * 30, 1.0f);
            else
                GameManager.instance.ShowText("BLOK", 25, Color.green, transform.position, Vector3.up * 30, 1.0f);

            if (hitPoint <= 0)
            {
                hitPoint = 0;
                Death();
            }
        }
    }


    protected virtual void Death()
    {

    }



}
