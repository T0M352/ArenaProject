using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Opcjonalne_ruchKamery : MonoBehaviour
{
    public Transform lookAt;

    private void LateUpdate()
    {
        transform.position = new Vector3(lookAt.position.x, lookAt.position.y, -10);

    }
}
