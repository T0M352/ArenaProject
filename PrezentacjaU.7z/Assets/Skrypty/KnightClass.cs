using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnightClass : PlayerOne
{

    private bool IsUlt;
    protected override void Update()
    {
        base.Update();

        if (Input.GetKeyUp(KeyCode.Keypad3) && gameObject.name == "Player2Knight" && ultTimer == 0)
        {
            ultTimer = 100;
            Instantiate(GameManager.instance.KnightUltPS, transform.position, transform.rotation, transform);
            StartCoroutine(KnightUlt());
        }
        if (Input.GetKeyUp(KeyCode.H) && gameObject.name == "Player1Knight" && ultTimer == 0)
        {
            ultTimer = 100;
            Instantiate(GameManager.instance.KnightUltPS, transform.position, transform.rotation, transform);
            StartCoroutine(KnightUlt());
        }

        if (IsUlt == true)
            lastImmune = Time.time + 1f;

    }


    protected override void FixedUpdate()
    {
        base.FixedUpdate();
        if (moveDirectory == Vector3.zero)  //ZMIANA ANIMACJI RUCHU NA BIEG
            animator.SetBool("isMoving", false);
        else
            animator.SetBool("isMoving", true);
    }

        IEnumerator KnightUlt()
    {
            IsUlt = true;
            yield return new WaitForSeconds(10f);
            IsUlt = false;

    }
}
